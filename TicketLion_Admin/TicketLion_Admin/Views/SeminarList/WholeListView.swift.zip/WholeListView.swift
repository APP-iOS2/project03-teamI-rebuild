//
//  WholeListView.swift
//  TicketLion_Admin
//
//  Created by 아라 on 2023/09/06.
//

import SwiftUI

struct WholeListView: View {
    @EnvironmentObject var seminarStore: SeminarListStore
    @State private var selectedSeminar: Seminar.ID? = nil
    
    var body: some View {
        NavigationStack {
            if let seminarId = selectedSeminar {
                NavigationLink {
                    SeminarDetail()
                } label: {
                    Text("")
                }
            } else {
                VStack {
                    HStack {
                        Spacer()
                        NavigationLink {
                            SeminarAddView().environmentObject(seminarStore)
                        } label: {
                            Text("추가")
                                .font(.title2).bold()
                        }
                        .padding(.horizontal, 20)
                    }
                    
                    Table(of: Seminar.self, selection: $selectedSeminar) {
                        TableColumn("세미나명") { seminar in
                            Text(seminar.name)
                        }
                        TableColumn("주최자") { seminar in
                            Text(seminar.host)
                        }
                        TableColumn("장소") { seminar in
                            Text(seminar.location ?? "온라인")
                        }
                        TableColumn("참여인원") { seminar in
                            Text(("\(seminar.enterUsers.count)/\(seminar.maximumUserNumber)"))
                        }
                        TableColumn("마감여부") { seminar in
                            Text(seminar.closingStatus ? "마감" : "진행중")
                        }
                    } rows: {
                        ForEach(seminarStore.seminalList) { seminar in
                            TableRow(seminar)
                        }
                    }
                }
            }
        }
        .tint(Color(hex: 0xD7D7D9))
        .foregroundColor(.black)
    }
}

struct WholeListView_Previews: PreviewProvider {
    static var previews: some View {
        WholeListView().environmentObject(SeminarListStore())
    }
}
